package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Book;
import com.example.demo.repository.BookRepostitory;

@Component
public class BookServiceImpl implements BookService {
	@Autowired
	BookRepostitory bookRepository;

	@Override
	public List<Book> getAllBooks()
	{
		List<Book> bookList=bookRepository.findAll();
		return bookList;
	}

	@Override
	public Boolean saveBook(Book book) 
	{
		Book book1=bookRepository.save(book);
		return book1!=null?true:false;
	}

	@Override
	public Book getBookById(int id) {
		Book book2=bookRepository.findById(id).orElse(null);
		return book2!=null?book2:new Book(id);
	}

	@Override
	public String deleteBook(int id) 
	{
		String msg="";
		Book book3=bookRepository.findById(id).orElse(null);
		if(book3!=null)
		{
			bookRepository.deleteById(id);
			msg="Book with Id : "+id+" is deleted.";
			
		}
		else
		{
			msg="Book with Id:"+" is not present.";
		}
		
		return msg;
		
	}

	@Override
	public Book updateBookDetails(Book book) {
		return bookRepository.save(book);
	}

}
