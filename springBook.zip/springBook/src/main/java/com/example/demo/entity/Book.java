package com.example.demo.entity;

import java.sql.Date;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="books")
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(nullable = false)
	private String title;
	
	@Column(nullable = false)
	private String author;
	
	@Column(nullable = false)
	private double price;
	
    private Date publicationDate;
	public Book() {}
	public Book(int id) 
	{
		super();
		this.id = id;
	}
	
	public Book(String title, String author, double price, Date publicationDate) {
		super();
		this.title = title;
		this.author = author;
		this.price = price;
		this.publicationDate = publicationDate;
	}
	public Book(int id, String title, String author, double price, Date publicationDate) {
		super();
		this.id = id;
		this.title = title;
		this.author = author;
		this.price = price;
		this.publicationDate = publicationDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Date getPublicationDate() {
		return publicationDate;
	}
	public void setPublicationDate(Date publicationDate) {
		this.publicationDate = publicationDate;
	}
	
	@Override
	public String toString() {
		return "id: "+id+"\ntitle : "+title+"\nAuthor : "+author+"\nPrice : "+price+"\nPublication Date : "+publicationDate;
	}
	
}
