package com.example.demo;

import java.util.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.example.demo.entity.Book;
import com.example.demo.service.BookService;
import com.example.demo.service.BookServiceImpl;

@SpringBootApplication
@ComponentScan("com.example.demo.service")
public class SpringBookApplication {

	public static void main(String[] args) throws IOException, ParseException
	{
		Scanner sc = new Scanner(System.in);
		org.springframework.context.ApplicationContext appConfig=SpringApplication.run(SpringBookApplication.class, args);
		BookService bookService=appConfig.getBean(BookServiceImpl.class);

		
		int ch=0;
		/*
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String ch1=br.readLine();
		int ch=Integer.parseInt("ch1");*/
		
		do
		{
			menu();
			ch=sc.nextInt();
			
			
			switch(ch)
			{
				case 1:
					List<Book> books=bookService.getAllBooks();
					//System.out.println(books);
						books.forEach(b->System.out.println("\n"+b));
					break;
					
				case 2:
					System.out.println("Enter Title :");
					String btitle=sc.next();
					
					System.out.println("Enter Author :");
					String bAuthor=sc.next();
					
					System.out.println("Enter Price :");
					Double bPrice=sc.nextDouble();
					
					System.out.println("Enter day of date: ");
					int d=sc.nextInt();

					System.out.println("Enter day of month: ");
					int m=sc.nextInt();

					System.out.println("Enter day of year: ");
					int y=sc.nextInt();
					//System.out.println(LocalDate.of(y, m, d).toString());
					ZoneId defaultZoneId = ZoneId.systemDefault();
					LocalDate localDate = LocalDate.of(y, m, d);
				   Date date =Date.valueOf(localDate);
				        
				Boolean b=	 bookService.saveBook(new Book(btitle, bAuthor, bPrice,date));
				if(b)
					System.out.println("record inserted");
				else
					System.out.println("record does not inserted");
				    break;
				    
				case 3:
					System.out.println("Insert id :");
					int id=sc.nextInt();
					Book book=bookService.getBookById(id);
					System.out.println("\nTitle : "+book.getTitle()+"\nAuthor : "+book.getAuthor()+"\nPrice : "+book.getPrice()+"\nPblication Date :"+book.getPublicationDate()+"\n\n");
					break;
					
				case 4:
					System.out.println("Insert id :");
					int id2=sc.nextInt();
					String str=bookService.deleteBook(id2);
					System.out.println(str);
					break;
					
				case 5:
					System.out.println("Enter details:");
					System.out.println("Enter Title :");
					String title=sc.next();
					
					System.out.println("Enter Author :");
					String author=sc.next();
					
					System.out.println("Enter Price :");
					Double price=sc.nextDouble();
					
					System.out.println("Enter day of date: ");
					int d1=sc.nextInt();

					System.out.println("Enter day of month: ");
					int m1=sc.nextInt();

					System.out.println("Enter day of year: ");
					int y1=sc.nextInt();
					ZoneId defaultZoneId1 = ZoneId.systemDefault();
					LocalDate localDate1 = LocalDate.of(y1, m1, d1);
				   Date date1 =Date.valueOf(localDate1);
				   
				   Book book2=bookService.updateBookDetails(new Book(title,author,price,date1));
				   if(book2!=null)
				   {
					   System.out.println("record updated");
				   }
				   break;
				   
				  default :
					  System.out.println("invalid choice");
			}
			
		}while(ch!=6);
		
		
	}
	
	
	public static void menu()
	{
		System.out.println("Menu : \n1.View All Books \n2.Save A Book \n3.View Book By Id\n4.Delete Book \n5.Update Book \n6.Exit");
		System.out.println("Enter Your Choice : ");
	}
	
	

}
